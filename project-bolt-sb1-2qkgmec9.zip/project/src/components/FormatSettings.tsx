import React from 'react';
import { Settings } from 'lucide-react';

interface FormatSettingsProps {
  settings: {
    fontSize: number;
    lineHeight: number;
    marginSize: number;
  };
  onSettingsChange: (settings: any) => void;
}

export const FormatSettings: React.FC<FormatSettingsProps> = ({ settings, onSettingsChange }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center mb-6">
        <Settings className="w-6 h-6 text-blue-500 mr-2" />
        <h2 className="text-xl font-semibold text-gray-800">Format Settings</h2>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Font Size ({settings.fontSize}px)
          </label>
          <input
            type="range"
            min="12"
            max="24"
            value={settings.fontSize}
            onChange={(e) => onSettingsChange({ ...settings, fontSize: Number(e.target.value) })}
            className="w-full"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Line Height ({settings.lineHeight})
          </label>
          <input
            type="range"
            min="1"
            max="2"
            step="0.1"
            value={settings.lineHeight}
            onChange={(e) => onSettingsChange({ ...settings, lineHeight: Number(e.target.value) })}
            className="w-full"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Margin Size ({settings.marginSize}px)
          </label>
          <input
            type="range"
            min="0"
            max="100"
            value={settings.marginSize}
            onChange={(e) => onSettingsChange({ ...settings, marginSize: Number(e.target.value) })}
            className="w-full"
          />
        </div>
      </div>
    </div>
  );
};
import React from 'react';
import { List } from 'lucide-react';

interface ChapterListProps {
  chapters: string[];
  onChapterSelect: (index: number) => void;
}

export const ChapterList: React.FC<ChapterListProps> = ({ chapters, onChapterSelect }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center mb-6">
        <List className="w-6 h-6 text-blue-500 mr-2" />
        <h2 className="text-xl font-semibold text-gray-800">Table of Contents</h2>
      </div>
      <div className="space-y-2">
        {chapters.map((chapter, index) => (
          <button
            key={index}
            onClick={() => onChapterSelect(index)}
            className="w-full text-left px-4 py-2 rounded hover:bg-gray-100 transition-colors"
          >
            {chapter}
          </button>
        ))}
      </div>
    </div>
  );
};
import React, { useState } from 'react';
import { Download, Book } from 'lucide-react';

interface ExportOptionsProps {
  onExport: (title: string, author: string) => Promise<void>;
  isPremium: boolean;
}

export const ExportOptions: React.FC<ExportOptionsProps> = ({ onExport, isPremium }) => {
  const [title, setTitle] = useState('');
  const [author, setAuthor] = useState('');
  const [isExporting, setIsExporting] = useState(false);

  const handleExport = async () => {
    if (!title || !author) {
      alert('Please fill in both title and author fields');
      return;
    }

    setIsExporting(true);
    try {
      await onExport(title, author);
    } catch (error) {
      console.error('Export failed:', error);
      alert('Failed to export document. Please try again.');
    }
    setIsExporting(false);
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <div className="flex items-center mb-6">
        <Book className="w-6 h-6 text-blue-500 mr-2" />
        <h2 className="text-xl font-semibold text-gray-800">Export Settings</h2>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Book Title
          </label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Enter book title"
          />
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Author Name
          </label>
          <input
            type="text"
            value={author}
            onChange={(e) => setAuthor(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="Enter author name"
          />
        </div>

        {!isPremium && (
          <div className="text-sm text-gray-500 bg-yellow-50 p-3 rounded">
            Free tier exports will include a watermark. Upgrade to premium to remove it.
          </div>
        )}

        <button
          onClick={handleExport}
          disabled={isExporting}
          className="w-full flex items-center justify-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
        >
          <Download className="w-5 h-5 mr-2" />
          {isExporting ? 'Exporting...' : 'Export for Kindle'}
        </button>
      </div>
    </div>
  );
};
import React from 'react';
import { Book } from 'lucide-react';

interface DocumentPreviewProps {
  content: string;
  settings: {
    fontSize: number;
    lineHeight: number;
    marginSize: number;
  };
}

export const DocumentPreview: React.FC<DocumentPreviewProps> = ({ content, settings }) => {
  // Split content into paragraphs and remove empty ones, but preserve intentional line breaks
  const paragraphs = content.split('\n\n').map(p => p.trim()).filter(Boolean);

  return (
    <div className="bg-white rounded-lg shadow-lg overflow-hidden">
      <div className="flex items-center justify-between p-6 border-b border-gray-200">
        <h2 className="text-2xl font-bold text-gray-800">Preview</h2>
        <Book className="w-6 h-6 text-blue-500" />
      </div>
      
      <div 
        className="p-8 max-h-[800px] overflow-y-auto bg-white"
        style={{
          padding: `${settings.marginSize}px`,
        }}
      >
        {!content || paragraphs.length === 0 ? (
          <div className="text-center text-gray-500 py-8">
            <Book className="w-12 h-12 mx-auto mb-4 text-gray-300" />
            <p className="text-lg">Upload a document to see the preview</p>
            <p className="text-sm mt-2">Supported formats: .docx, .txt</p>
          </div>
        ) : (
          <div 
            className="prose prose-lg max-w-none"
            style={{
              fontSize: `${settings.fontSize}px`,
              lineHeight: settings.lineHeight,
              minHeight: '500px',
            }}
          >
            {paragraphs.map((paragraph, index) => (
              <p 
                key={index} 
                className="mb-6 last:mb-0"
                style={{
                  textIndent: '2em',
                  textAlign: 'justify',
                  hyphens: 'auto',
                  wordBreak: 'normal',
                  overflowWrap: 'break-word'
                }}
              >
                {paragraph}
              </p>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
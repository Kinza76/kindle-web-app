import { convert } from 'html-to-text';
import EPub from 'epub-gen';

interface Chapter {
  title: string;
  content: string;
}

interface ProcessedDocument {
  chapters: Chapter[];
  toc: string[];
}

export const processDocument = async (content: string): Promise<ProcessedDocument> => {
  // Normalize line endings and clean up extra whitespace
  const normalizedContent = content
    .replace(/\r\n/g, '\n')
    .replace(/\r/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  // Split content into chapters based on headers
  const chapters: Chapter[] = [];
  const blocks = normalizedContent.split(/\n\n+/);
  let currentChapter: Chapter = { title: 'Chapter 1', content: '' };
  
  const headerRegex = /^(?:Chapter|Section|\d+\.|\#)\s+.+/i;
  
  // Check if the document has chapter markers
  const hasChapters = blocks.some(block => headerRegex.test(block.trim()));
  
  if (!hasChapters) {
    return {
      chapters: [{
        title: 'Chapter 1',
        content: normalizedContent
      }],
      toc: ['Chapter 1']
    };
  }
  
  blocks.forEach(block => {
    const trimmedBlock = block.trim();
    if (headerRegex.test(trimmedBlock)) {
      if (currentChapter.content) {
        chapters.push({ ...currentChapter });
      }
      currentChapter = {
        title: trimmedBlock,
        content: ''
      };
    } else if (trimmedBlock) {
      currentChapter.content += (currentChapter.content ? '\n\n' : '') + trimmedBlock;
    }
  });
  
  // Add the last chapter if it has content
  if (currentChapter.content) {
    chapters.push(currentChapter);
  }

  // If no chapters were created, create a single chapter
  if (chapters.length === 0) {
    chapters.push({
      title: 'Chapter 1',
      content: normalizedContent
    });
  }

  return {
    chapters,
    toc: chapters.map(ch => ch.title)
  };
};

interface FormatSettings {
  fontSize: number;
  lineHeight: number;
  marginSize: number;
}

export const generateEpub = async (
  title: string,
  author: string,
  chapters: Chapter[],
  settings: FormatSettings,
  isFreeTier: boolean
): Promise<Blob> => {
  const options = {
    title,
    author,
    content: chapters.map(chapter => ({
      title: chapter.title,
      data: `
        <div style="
          font-size: ${settings.fontSize}px;
          line-height: ${settings.lineHeight};
          margin: ${settings.marginSize}px;
          text-align: justify;
          hyphens: auto;
        ">
          <h1 style="text-align: center; margin-bottom: 2em;">${chapter.title}</h1>
          ${chapter.content.split('\n\n').map(p => 
            `<p style="text-indent: 2em; margin-bottom: 1em;">${p.trim()}</p>`
          ).join('\n')}
          ${isFreeTier ? '<div style="position: fixed; bottom: 10px; right: 10px; opacity: 0.5;">Created with Kindle Formatter</div>' : ''}
        </div>
      `
    }))
  };

  return new Promise((resolve, reject) => {
    try {
      const epub = new EPub(options);
      epub.genEpub()
        .then(content => {
          const blob = new Blob([content], { type: 'application/epub+zip' });
          resolve(blob);
        })
        .catch(reject);
    } catch (error) {
      reject(error);
    }
  });
};
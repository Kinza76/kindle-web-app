import React, { useState } from 'react';
import { FileUpload } from './components/FileUpload';
import { DocumentPreview } from './components/DocumentPreview';
import { FormatSettings } from './components/FormatSettings';
import { ChapterList } from './components/ChapterList';
import { ExportOptions } from './components/ExportOptions';
import { Book } from 'lucide-react';
import { processDocument, generateEpub } from './lib/documentProcessor';
import { useAuthStore } from './store/authStore';

interface Chapter {
  title: string;
  content: string;
}

function App() {
  const [content, setContent] = useState<string>('');
  const [chapters, setChapters] = useState<Chapter[]>([]);
  const [currentChapterIndex, setCurrentChapterIndex] = useState(0);
  const [settings, setSettings] = useState({
    fontSize: 16,
    lineHeight: 1.5,
    marginSize: 20,
  });

  // In a real app, this would come from your subscription check
  const isPremium = false;

  const handleFileSelect = async (file: File) => {
    try {
      let text = '';
      if (file.name.endsWith('.txt')) {
        text = await file.text();
      } else if (file.name.endsWith('.docx')) {
        const mammoth = await import('mammoth');
        const arrayBuffer = await file.arrayBuffer();
        const result = await mammoth.extractRawText({ arrayBuffer });
        text = result.value;
      }

      setContent(text);
      const processed = await processDocument(text);
      setChapters(processed.chapters);
      setCurrentChapterIndex(0); // Reset to first chapter
    } catch (error) {
      console.error('Error processing file:', error);
      alert('Error processing file. Please try again.');
    }
  };

  const handleExport = async (title: string, author: string) => {
    try {
      const blob = await generateEpub(
        title,
        author,
        chapters,
        settings,
        !isPremium // watermark for free tier
      );
      
      // Create a download link
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${title.toLowerCase().replace(/\s+/g, '-')}.epub`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Export failed:', error);
      alert('Failed to export document. Please try again.');
    }
  };

  const currentContent = chapters.length > 0 ? chapters[currentChapterIndex].content : content;

  return (
    <div className="min-h-screen bg-gray-100 py-8 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <Book className="w-8 h-8 text-blue-500 mr-2" />
            <h1 className="text-3xl font-bold text-gray-900">Kindle Book Formatter</h1>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
          <div className="md:col-span-3 space-y-8">
            <FileUpload onFileSelect={handleFileSelect} />
            <FormatSettings settings={settings} onSettingsChange={setSettings} />
            {chapters.length > 0 && (
              <ChapterList
                chapters={chapters.map(ch => ch.title)}
                onChapterSelect={setCurrentChapterIndex}
              />
            )}
            <ExportOptions
              onExport={handleExport}
              isPremium={isPremium}
            />
          </div>

          <div className="md:col-span-9">
            <DocumentPreview
              content={currentContent}
              settings={settings}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;